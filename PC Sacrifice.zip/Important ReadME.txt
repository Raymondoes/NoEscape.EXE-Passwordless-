run this whole thing on a VM, or if you are a dumbass enough run this on your main hardware
VMs:
VMWare (Paid)
Virtualbox (Free)